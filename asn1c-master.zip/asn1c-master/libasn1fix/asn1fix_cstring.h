#ifndef	ASN1FIX_CSTRING_H
#define	ASN1FIX_CSTRING_H

int asn1f_fix_cstring(arg_t *);

#endif	/* ASN1FIX_CSTRING_H */
