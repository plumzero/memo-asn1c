#ifndef	ASN1FIX_DEREFT_H
#define	ASN1FIX_DEREFT_H

int asn1f_fix_dereference_types(arg_t *);

#endif	/* ASN1FIX_DEREFT_H */
