#ifndef	ASN1FIX_ENUM_H
#define	ASN1FIX_ENUM_H

int asn1f_fix_enum(arg_t *);	/* Enumeration ::= ENUMERATED { a(1), b(2) } */

#endif	/* ASN1FIX_ENUM_H */
